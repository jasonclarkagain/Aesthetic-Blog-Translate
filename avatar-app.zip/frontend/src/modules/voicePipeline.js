/**
 * Layer 4 — Voice & Speech Layer
 *
 * STT: uses the browser's SpeechRecognition when available (zero backend,
 * zero latency to first result). For production-grade accuracy, swap in a
 * call to the backend's /api/stt (Whisper) route instead — same call shape.
 *
 * TTS: always goes through the backend so provider keys stay server-side.
 * Returns both an audio element and a viseme timeline so the avatar's mouth
 * can be driven by TTS output, not just live mic input.
 */

export class SpeechToText {
  constructor({ onResult, lang = "en-US" } = {}) {
    this.onResult = onResult;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      this.supported = false;
      return;
    }
    this.supported = true;
    this.recognizer = new SR();
    this.recognizer.continuous = true;
    this.recognizer.interimResults = true;
    this.recognizer.lang = lang;
    this.recognizer.onresult = (event) => {
      const result = event.results[event.results.length - 1];
      this.onResult?.({
        text: result[0].transcript,
        isFinal: result.isFinal,
      });
    };
  }

  start() {
    if (!this.supported) throw new Error("SpeechRecognition not supported in this browser");
    this.recognizer.start();
  }

  stop() {
    this.recognizer?.stop();
  }
}

export class TextToSpeech {
  constructor({ backendUrl }) {
    this.backendUrl = backendUrl;
  }

  /**
   * @param {string} text
   * @returns {Promise<{ audio: HTMLAudioElement, visemes: Array<{time: number, viseme: string}> }>}
   */
  async speak(text) {
    const res = await fetch(`${this.backendUrl}/api/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    if (!res.ok) throw new Error(`TTS request failed: ${res.status}`);
    const { audioUrl, visemes } = await res.json();

    const audio = new Audio(audioUrl);
    return { audio, visemes: visemes ?? [] };
  }
}

/**
 * Schedules avatar mouth shapes against an already-playing audio element
 * using a viseme timeline returned by the TTS backend.
 *
 * @param {HTMLAudioElement} audio
 * @param {Array<{time:number, viseme:string}>} visemes
 * @param {(viseme:string)=>void} applyViseme
 */
export function syncVisemesToAudio(audio, visemes, applyViseme) {
  let idx = 0;
  const tick = () => {
    if (audio.paused || audio.ended) return;
    const t = audio.currentTime * 1000;
    while (idx < visemes.length && visemes[idx].time <= t) {
      applyViseme(visemes[idx].viseme);
      idx += 1;
    }
    requestAnimationFrame(tick);
  };
  audio.addEventListener("play", () => {
    idx = 0;
    tick();
  });
}
