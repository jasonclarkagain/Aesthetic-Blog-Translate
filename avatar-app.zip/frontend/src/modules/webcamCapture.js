/**
 * Layer 1 — Webcam Input Layer
 *
 * Wraps getUserMedia and gives the rest of the app a clean pull-based API:
 * call getFrameTimestamp()/videoElement whenever the tracker is ready for
 * the next frame, rather than pushing frames faster than they can be
 * processed.
 */
export class WebcamCapture {
  constructor({ width = 640, height = 480, facingMode = "user" } = {}) {
    this.constraints = {
      video: { width, height, facingMode },
      audio: false,
    };
    this.videoEl = document.createElement("video");
    this.videoEl.autoplay = true;
    this.videoEl.playsInline = true;
    this.videoEl.muted = true;
    this.stream = null;
  }

  /** Request camera permission and start the stream. */
  async start() {
    this.stream = await navigator.mediaDevices.getUserMedia(this.constraints);
    this.videoEl.srcObject = this.stream;
    await this.videoEl.play();
    // Wait for the first real frame so downstream consumers get valid
    // dimensions immediately.
    if (this.videoEl.readyState < 2) {
      await new Promise((resolve) =>
        this.videoEl.addEventListener("loadeddata", resolve, { once: true })
      );
    }
    return this.videoEl;
  }

  /** Stop all tracks and release the camera. */
  stop() {
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
  }

  /** The live <video> element — pass this directly into FaceLandmarker.detectForVideo(). */
  get element() {
    return this.videoEl;
  }

  get isActive() {
    return !!this.stream && this.stream.active;
  }
}
