/**
 * Layer 2 — Face & Motion Tracking Layer
 *
 * Wraps MediaPipe Tasks Vision's FaceLandmarker to produce, per video frame:
 *  - 478 3D face landmarks
 *  - 52 ARKit-style blendshape coefficients (eye blink, brow raise, jaw
 *    open, mouth shapes, etc.) — this is what drives the avatar's expression
 *  - a 4x4 facial transformation matrix — this is what drives head pose
 *
 * Runs entirely in the browser (WASM, GPU-accelerated where available).
 */
import {
  FaceLandmarker,
  FilesetResolver,
} from "@mediapipe/tasks-vision";

const WASM_BASE =
  "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const MODEL_URL =
  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

export class FaceTracker {
  constructor() {
    this.landmarker = null;
    this.lastVideoTime = -1;
  }

  async init() {
    const filesetResolver = await FilesetResolver.forVisionTasks(WASM_BASE);
    this.landmarker = await FaceLandmarker.createFromOptions(filesetResolver, {
      baseOptions: {
        modelAssetPath: MODEL_URL,
        delegate: "GPU",
      },
      outputFaceBlendshapes: true,
      outputFacialTransformationMatrixes: true,
      runningMode: "VIDEO",
      numFaces: 1,
    });
  }

  /**
   * Call once per rendered frame with the live <video> element.
   * Returns null if no new frame is available yet, or no face was found.
   *
   * @returns {{
   *   blendshapes: Record<string, number>,
   *   headMatrix: Float32Array | null,
   *   timestamp: number
   * } | null}
   */
  detect(videoEl) {
    if (!this.landmarker) throw new Error("FaceTracker.init() not called yet");
    if (videoEl.currentTime === this.lastVideoTime) return null;
    this.lastVideoTime = videoEl.currentTime;

    const nowMs = performance.now();
    const result = this.landmarker.detectForVideo(videoEl, nowMs);

    if (!result.faceLandmarks?.length) return null;

    const blendshapes = {};
    for (const category of result.faceBlendshapes?.[0]?.categories ?? []) {
      blendshapes[category.categoryName] = category.score;
    }

    const headMatrix =
      result.facialTransformationMatrixes?.[0]?.data ?? null;

    return {
      landmarks: result.faceLandmarks[0],
      blendshapes,
      headMatrix,
      timestamp: nowMs,
    };
  }

  dispose() {
    this.landmarker?.close();
    this.landmarker = null;
  }
}
