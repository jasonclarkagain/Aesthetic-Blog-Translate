/**
 * Layer 3 — Avatar Rendering Layer
 *
 * Defines a single `AvatarRenderer` interface so App.jsx (Layer 6) never
 * needs to know whether frames come from a local rigged model or a remote
 * photoreal streaming API.
 *
 *   interface AvatarRenderer {
 *     mount(containerEl: HTMLElement): Promise<void>
 *     pushFrame(trackingFrame: TrackingFrame): void   // called every tracked frame
 *     dispose(): void
 *   }
 */
import * as THREE from "three";
import { VRMLoaderPlugin, VRMUtils } from "@pixiv/three-vrm";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

// MediaPipe blendshape category names -> VRM standard expression names.
// VRM 1.0 uses these preset names; extend this map for a richer rig.
const BLENDSHAPE_TO_VRM = {
  eyeBlinkLeft: "blinkLeft",
  eyeBlinkRight: "blinkRight",
  jawOpen: "aa",
  mouthSmileLeft: "happy",
  mouthSmileRight: "happy",
  mouthFunnel: "ou",
  mouthPucker: "ou",
  browInnerUp: "surprised",
};

/**
 * Option A — local, real-time, zero API cost. Stylized 3D by default;
 * fidelity depends entirely on the .vrm asset you load.
 */
export class RiggedVRMRenderer {
  constructor({ vrmUrl }) {
    this.vrmUrl = vrmUrl;
    this.vrm = null;
    this.scene = null;
    this.renderer = null;
    this.camera = null;
    this.clock = new THREE.Clock();
    this._raf = null;
  }

  async mount(containerEl) {
    const width = containerEl.clientWidth || 480;
    const height = containerEl.clientHeight || 480;

    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    containerEl.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(30, width / height, 0.1, 20);
    this.camera.position.set(0, 1.4, 1.6);

    const light = new THREE.DirectionalLight(0xffffff, 1.2);
    light.position.set(1, 1, 1);
    this.scene.add(light);
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.6));

    const loader = new GLTFLoader();
    loader.register((parser) => new VRMLoaderPlugin(parser));
    const gltf = await loader.loadAsync(this.vrmUrl);
    this.vrm = gltf.userData.vrm;
    VRMUtils.rotateVRM0(this.vrm); // face +Z if the asset is VRM0-style
    this.scene.add(this.vrm.scene);

    this._animate();
  }

  /** Drive expression + head pose from a tracker frame. */
  pushFrame({ blendshapes, headMatrix }) {
    if (!this.vrm) return;

    const expr = this.vrm.expressionManager;
    if (expr && blendshapes) {
      // Reset then apply, so un-driven expressions relax to neutral.
      for (const name of expr.expressionMap ? Object.keys(expr.expressionMap) : []) {
        expr.setValue(name, 0);
      }
      for (const [mpName, value] of Object.entries(blendshapes)) {
        const vrmName = BLENDSHAPE_TO_VRM[mpName];
        if (vrmName) expr.setValue(vrmName, Math.min(1, value * 1.2));
      }
    }

    if (headMatrix && this.vrm.humanoid) {
      const head = this.vrm.humanoid.getNormalizedBoneNode("head");
      if (head) {
        const m = new THREE.Matrix4().fromArray(headMatrix);
        const q = new THREE.Quaternion().setFromRotationMatrix(m);
        head.quaternion.slerp(q, 0.5); // smooth toward target pose
      }
    }
  }

  _animate = () => {
    this._raf = requestAnimationFrame(this._animate);
    const dt = this.clock.getDelta();
    this.vrm?.update(dt);
    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    cancelAnimationFrame(this._raf);
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
  }
}

/**
 * Option B — photoreal streaming AI avatar. This is a stub against whatever
 * vendor you choose (HeyGen Streaming Avatar, D-ID Agents, Simli, Tavus).
 * Fill in `_connect`/`_send` per that vendor's SDK — the shape of the class
 * (mount/pushFrame/dispose) stays the same so App.jsx doesn't change.
 */
export class StreamingAvatarRenderer {
  constructor({ apiKey, avatarId, backendUrl }) {
    this.apiKey = apiKey;
    this.avatarId = avatarId;
    this.backendUrl = backendUrl; // route session/token minting through your backend, not the client
    this.videoEl = null;
    this.session = null;
  }

  async mount(containerEl) {
    this.videoEl = document.createElement("video");
    this.videoEl.autoplay = true;
    this.videoEl.playsInline = true;
    containerEl.appendChild(this.videoEl);

    // 1. Ask your backend to mint a short-lived session token (never ship
    //    the vendor API key to the browser).
    const res = await fetch(`${this.backendUrl}/api/avatar-session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ avatarId: this.avatarId }),
    });
    const { sessionToken, iceServers } = await res.json();

    // 2. Open the vendor's WebRTC/WebSocket session with that token and
    //    attach the returned media stream to this.videoEl.
    //    (Vendor-specific SDK call goes here — see README §Integration.)
    this.session = { sessionToken, iceServers, connected: false };
  }

  /**
   * Streaming avatar vendors typically want either (a) raw audio to drive
   * lip sync themselves, or (b) blendshape/viseme parameters. Forward
   * whichever this vendor expects.
   */
  pushFrame(trackingFrame) {
    if (!this.session?.connected) return;
    // this.session.dataChannel.send(JSON.stringify(trackingFrame));
  }

  dispose() {
    this.session = null;
    this.videoEl?.remove();
  }
}
