/**
 * Layer 5 — AI Brain Layer (optional)
 *
 * Thin client for the backend's /api/llm route. All prompt construction,
 * provider selection, and memory persistence live server-side — this module
 * just sends turns and gets text back.
 */
export class AIBrain {
  constructor({ backendUrl, sessionId }) {
    this.backendUrl = backendUrl;
    this.sessionId = sessionId ?? crypto.randomUUID();
  }

  /**
   * @param {string} userText
   * @returns {Promise<string>} the persona's reply text (for TTS to speak)
   */
  async respond(userText) {
    const res = await fetch(`${this.backendUrl}/api/llm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: this.sessionId, message: userText }),
    });
    if (!res.ok) throw new Error(`AI brain request failed: ${res.status}`);
    const { reply } = await res.json();
    return reply;
  }

  async clearMemory() {
    await fetch(`${this.backendUrl}/api/llm/session/${this.sessionId}`, {
      method: "DELETE",
    });
  }
}
