import React, { useEffect, useRef, useState } from "react";
import { WebcamCapture } from "./modules/webcamCapture.js";
import { FaceTracker } from "./modules/faceTracker.js";
import { RiggedVRMRenderer } from "./modules/avatarRenderer.js";
import { SpeechToText, TextToSpeech, syncVisemesToAudio } from "./modules/voicePipeline.js";
import { AIBrain } from "./modules/aiBrain.js";

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:8787";
const VRM_URL = "/avatars/persona.vrm";

export default function App() {
  const webcamPipRef = useRef(null);
  const avatarStageRef = useRef(null);
  const pipelineRef = useRef({});
  const [status, setStatus] = useState("idle");
  const [blendshapes, setBlendshapes] = useState({});
  const [transcript, setTranscript] = useState("");
  const [brainEnabled, setBrainEnabled] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function boot() {
      setStatus("requesting camera");
      const webcam = new WebcamCapture({ width: 640, height: 480 });
      const videoEl = await webcam.start();
      if (cancelled) return;
      webcamPipRef.current.appendChild(videoEl);
      videoEl.classList.add("pip-video");

      setStatus("loading tracker");
      const tracker = new FaceTracker();
      await tracker.init();
      if (cancelled) return;

      setStatus("loading avatar");
      const renderer = new RiggedVRMRenderer({ vrmUrl: VRM_URL });
      await renderer.mount(avatarStageRef.current);
      if (cancelled) return;

      pipelineRef.current = { webcam, tracker, renderer };
      setStatus("live");

      const loop = () => {
        const frame = tracker.detect(videoEl);
        if (frame) {
          renderer.pushFrame(frame);
          setBlendshapes(frame.blendshapes);
        }
        pipelineRef.current.raf = requestAnimationFrame(loop);
      };
      loop();
    }

    boot().catch((err) => {
      console.error(err);
      setStatus(`error: ${err.message}`);
    });

    return () => {
      cancelled = true;
      cancelAnimationFrame(pipelineRef.current.raf);
      pipelineRef.current.tracker?.dispose();
      pipelineRef.current.renderer?.dispose();
      pipelineRef.current.webcam?.stop();
    };
  }, []);

  function toggleMic() {
    if (pipelineRef.current.stt?.recognizer) {
      pipelineRef.current.stt.stop();
      pipelineRef.current.stt = null;
      return;
    }
    const stt = new SpeechToText({
      onResult: async ({ text, isFinal }) => {
        setTranscript(text);
        if (isFinal && brainEnabled) {
          const brain = (pipelineRef.current.brain ??= new AIBrain({ backendUrl: BACKEND_URL }));
          const reply = await brain.respond(text);
          const tts = new TextToSpeech({ backendUrl: BACKEND_URL });
          const { audio, visemes } = await tts.speak(reply);
          syncVisemesToAudio(audio, visemes, (viseme) =>
            pipelineRef.current.renderer?.pushFrame({ blendshapes: { [viseme]: 1 } })
          );
          audio.play();
        }
      },
    });
    stt.start();
    pipelineRef.current.stt = stt;
  }

  const topBlendshapes = Object.entries(blendshapes)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);

  return (
    <div className="stage">
      <header className="stage__header">
        <div className="stage__title">
          <span className="dot" data-status={status === "live" ? "live" : "pending"} />
          LIVE AVATAR PIPELINE
        </div>
        <div className="stage__status">{status}</div>
      </header>

      <main className="stage__main">
        <section className="panel panel--avatar">
          <div className="panel__label">OUTPUT — PERSONA</div>
          <div className="avatar-canvas" ref={avatarStageRef} />
        </section>

        <aside className="panel panel--debug">
          <div className="panel__label">DEBUG — SOURCE FEED</div>
          <div className="pip" ref={webcamPipRef} />

          <div className="telemetry">
            <div className="telemetry__label">BLENDSHAPE TELEMETRY</div>
            {topBlendshapes.map(([name, value]) => (
              <div className="bar-row" key={name}>
                <span className="bar-row__name">{name}</span>
                <div className="bar-row__track">
                  <div className="bar-row__fill" style={{ width: `${value * 100}%` }} />
                </div>
                <span className="bar-row__value">{value.toFixed(2)}</span>
              </div>
            ))}
          </div>

          <div className="controls">
            <button onClick={toggleMic}>
              {pipelineRef.current.stt ? "Stop mic" : "Start mic"}
            </button>
            <label className="controls__toggle">
              <input
                type="checkbox"
                checked={brainEnabled}
                onChange={(e) => setBrainEnabled(e.target.checked)}
              />
              AI brain replies
            </label>
          </div>

          {transcript && <div className="transcript">“{transcript}”</div>}
        </aside>
      </main>
    </div>
  );
}
