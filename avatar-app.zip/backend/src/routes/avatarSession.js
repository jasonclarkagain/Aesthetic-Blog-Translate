import { Router } from "express";

export const avatarSessionRouter = Router();

/**
 * POST /api/avatar-session
 * body: { avatarId: string }
 * returns: { sessionToken: string, iceServers: RTCIceServer[] }
 *
 * Only needed if you're using Renderer B (StreamingAvatarRenderer) from
 * avatarRenderer.js. This mints a short-lived token from your streaming
 * avatar vendor server-side so the long-lived AVATAR_API_KEY never reaches
 * the browser. Fill in the vendor's session-create call.
 */
avatarSessionRouter.post("/", async (req, res) => {
  if (!process.env.AVATAR_API_KEY) {
    return res.status(501).json({ error: "AVATAR_API_KEY not configured" });
  }

  // Example only — replace with your vendor's session/token endpoint.
  // const upstream = await fetch(vendorSessionUrl, {
  //   method: "POST",
  //   headers: { Authorization: `Bearer ${process.env.AVATAR_API_KEY}` },
  //   body: JSON.stringify({ avatarId: req.body.avatarId }),
  // });
  // const { token, iceServers } = await upstream.json();

  res.status(501).json({
    error: "Wire up your streaming avatar vendor in routes/avatarSession.js",
  });
});
