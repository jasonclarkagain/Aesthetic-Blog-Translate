import { Router } from "express";

export const llmRouter = Router();

// In-memory per-session history. Swap for Redis/a DB for anything beyond a
// single-process dev/demo deployment.
const sessions = new Map();
const MAX_TURNS = 20;

/**
 * POST /api/llm
 * body: { sessionId: string, message: string }
 * returns: { reply: string }
 */
llmRouter.post("/", async (req, res) => {
  const { sessionId, message } = req.body;
  if (!sessionId || !message) {
    return res.status(400).json({ error: "sessionId and message required" });
  }
  if (!process.env.LLM_API_KEY) {
    return res.status(501).json({ error: "LLM_API_KEY not configured" });
  }

  const history = sessions.get(sessionId) ?? [];
  history.push({ role: "user", content: message });

  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.LLM_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.LLM_MODEL || "claude-sonnet-4-6",
        max_tokens: 400,
        messages: history,
      }),
    });
    if (!upstream.ok) throw new Error(`upstream ${upstream.status}`);
    const data = await upstream.json();
    const reply = data.content?.map((c) => c.text || "").join("") ?? "";

    history.push({ role: "assistant", content: reply });
    sessions.set(sessionId, history.slice(-MAX_TURNS));

    res.json({ reply });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

llmRouter.delete("/session/:id", (req, res) => {
  sessions.delete(req.params.id);
  res.json({ ok: true });
});
