import { Router } from "express";

export const sttRouter = Router();

/**
 * POST /api/stt
 * body: { audioBase64: string, mimeType: string }
 * returns: { text: string }
 *
 * Swap the fetch below for whichever transcription provider you use
 * (OpenAI Whisper API, Deepgram, AssemblyAI, self-hosted whisper.cpp).
 * This route exists because browser SpeechRecognition quality/availability
 * varies a lot across browsers — use this when you need consistent accuracy.
 */
sttRouter.post("/", async (req, res) => {
  const { audioBase64, mimeType = "audio/webm" } = req.body;
  if (!audioBase64) return res.status(400).json({ error: "audioBase64 required" });

  if (!process.env.WHISPER_API_KEY) {
    return res.status(501).json({ error: "WHISPER_API_KEY not configured" });
  }

  try {
    const audioBuffer = Buffer.from(audioBase64, "base64");
    const form = new FormData();
    form.append("file", new Blob([audioBuffer], { type: mimeType }), "audio.webm");
    form.append("model", "whisper-1");

    const upstream = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.WHISPER_API_KEY}` },
      body: form,
    });
    if (!upstream.ok) throw new Error(`upstream ${upstream.status}`);
    const data = await upstream.json();
    res.json({ text: data.text });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});
