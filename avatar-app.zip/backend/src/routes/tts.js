import { Router } from "express";

export const ttsRouter = Router();

/**
 * POST /api/tts
 * body: { text: string }
 * returns: { audioUrl: string, visemes: Array<{time:number, viseme:string}> }
 *
 * Fill in the provider call below. Providers that return phoneme/viseme
 * timing natively (Azure Speech, Amazon Polly with speech marks) make the
 * mouth-sync layer trivial — prefer those over rolling your own forced
 * aligner. This stub shows the Azure Speech shape as an example.
 */
ttsRouter.post("/", async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: "text required" });

  if (!process.env.TTS_API_KEY) {
    return res.status(501).json({ error: "TTS_API_KEY not configured" });
  }

  try {
    // Example only — replace with your provider's actual endpoint/SDK.
    // const upstream = await fetch(providerTtsUrl, { ... });
    // const { audioUrl, visemes } = await upstream.json();

    // Placeholder response shape so the frontend contract is exercised
    // even before a provider is wired up:
    res.status(501).json({
      error: "Wire up your TTS provider in routes/tts.js — see comments.",
    });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});
