import "dotenv/config";
import express from "express";
import cors from "cors";
import { sttRouter } from "./routes/stt.js";
import { ttsRouter } from "./routes/tts.js";
import { llmRouter } from "./routes/llm.js";
import { avatarSessionRouter } from "./routes/avatarSession.js";

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" })); // audio blobs can be sizeable

app.use("/api/stt", sttRouter);
app.use("/api/tts", ttsRouter);
app.use("/api/llm", llmRouter);
app.use("/api/avatar-session", avatarSessionRouter);

app.get("/healthz", (_req, res) => res.json({ ok: true }));

const port = process.env.PORT || 8787;
app.listen(port, () => {
  console.log(`avatar-app backend listening on :${port}`);
});
