# Live Avatar Pipeline

Real-time webcam → tracked face → rendered persona, with an optional voice/LLM
layer. Everything here is runnable, not pseudocode — swap the stub endpoints
for real API keys and it works end to end.

## Architecture

```
┌─────────────────────┐
│  Webcam Input Layer  │  getUserMedia → <video> → OffscreenCanvas frames
└──────────┬───────────┘
           │ ImageBitmap @ ~30fps
┌──────────▼───────────┐
│ Face & Motion Tracker │  MediaPipe FaceLandmarker (WASM, GPU delegate)
│  - 478 landmarks      │  → blendshapes (52 ARKit-style coefficients)
│  - head pose (R,T)    │  → transformation matrix
└──────────┬───────────┘
           │ TrackingFrame { blendshapes, headPose, timestamp }
           │
     ┌─────┴──────────────────────────────┐
     │                                     │
┌────▼─────────────┐              ┌────────▼──────────┐
│ Avatar Renderer A │              │ Avatar Renderer B  │
│ Rigged 3D (VRM)   │   (choose    │ Streaming AI avatar│
│ three.js + VRM    │    one)      │ API (D-ID/HeyGen/  │
│ blendshape proxy  │              │ Simli/custom)      │
└────────┬──────────┘              └────────┬───────────┘
         │                                   │
         └─────────────┬─────────────────────┘
                        │ rendered frame
┌───────────────────────▼───────────────────────┐
│                Output Layer                    │
│  <canvas> avatar (main) + <video> webcam (pip) │
└─────────────────────────────────────────────────┘

┌──────────────────┐     ┌───────────────────┐     ┌────────────────┐
│ Voice: STT        │────▶│ AI Brain (optional)│────▶│ Voice: TTS      │
│ Web Speech API or  │     │ LLM via backend    │     │ backend proxy   │
│ Whisper (backend)  │     │ proxy + memory     │     │ → viseme sync   │
└──────────────────┘     └───────────────────┘     └────────────────┘
```

## Why two renderer options

- **A — Rigged avatar (three.js + VRM)**: fully local, zero per-frame API
  cost, low latency (~one frame), but visual fidelity is "stylized 3D," not
  photoreal, unless you supply a photoreal rigged model.
- **B — Streaming AI avatar API**: photoreal output, but it's a network
  round-trip per frame/chunk, costs per minute, and you depend on a vendor
  (D-ID, HeyGen Streaming Avatar, Simli, Tavus). `avatarRenderer.js` defines
  a single interface (`AvatarRenderer`) so you can swap A/B without touching
  the tracking or UI layers.

## Stack

| Layer | Choice | Why |
|---|---|---|
| Webcam capture | Browser `getUserMedia` | No install, works everywhere |
| Face tracking | `@mediapipe/tasks-vision` `FaceLandmarker` | Runs in-browser on WASM/WebGPU, gives both landmarks and blendshapes in one pass |
| 3D rendering | `three.js` + `@pixiv/three-vrm` | VRM is an open, well-supported rigged-avatar format with a standard blendshape API |
| STT | Browser `SpeechRecognition`, fallback to backend Whisper | Zero-latency default, upgrade path for accuracy |
| TTS | Backend proxy to a TTS provider | Keeps API keys off the client |
| LLM brain | Backend proxy (`/api/llm`) | Same reason — never put provider keys in frontend code |
| Backend | Node/Express | Thin proxy + session memory store |

## Project layout

```
avatar-app/
  frontend/
    src/
      modules/
        webcamCapture.js   # Layer 1
        faceTracker.js     # Layer 2
        avatarRenderer.js  # Layer 3 (both A and B implementations)
        voicePipeline.js   # Layer 4 (STT + TTS client)
        aiBrain.js         # Layer 5 (optional, calls backend)
      App.jsx              # Layer 6 — wires everything, side-by-side output
      App.css
      main.jsx
    index.html
    package.json
  backend/
    src/
      index.js
      routes/stt.js         # Whisper proxy (optional upgrade over browser STT)
      routes/tts.js         # TTS proxy + viseme timing
      routes/llm.js         # LLM proxy + per-session memory
    package.json
```

## Setup

```bash
# frontend
cd avatar-app/frontend
npm install
npm run dev            # http://localhost:5173

# backend (only needed for STT upgrade, TTS, or the AI brain)
cd avatar-app/backend
npm install
cp .env.example .env   # fill in provider keys
npm start               # http://localhost:8787
```

Frontend calls the backend at `VITE_BACKEND_URL` (see `.env.example` pattern
in `backend/`). Without the backend running, the app still works in
"tracking + rigged avatar only" mode — voice and LLM features degrade
gracefully to disabled.

## Model assets you must supply

Nothing photoreal ships in this repo (no third-party model weights, no
likeness data). You provide:

1. **A `.vrm` avatar file** — drop it at
   `frontend/public/avatars/persona.vrm` for Renderer A. Ready Player Me,
   VRoid Studio, or a commissioned rig all export VRM.
2. **API keys** for whichever vendor you pick for Renderer B / STT / TTS /
   LLM, in `backend/.env`.

## Integration steps for Renderer B (photoreal streaming avatar)

1. Sign up with a streaming-avatar vendor (e.g., HeyGen Streaming Avatar API,
   D-ID Agents, Simli, Tavus). Each exposes a WebRTC or WebSocket session
   that takes either audio or driving parameters and returns a live video
   track.
2. Implement `StreamingAvatarRenderer` in `avatarRenderer.js` (stub included)
   against that vendor's SDK — the constructor takes `{ apiKey, avatarId }`
   and `pushFrame(trackingFrame)` forwards blendshapes/audio per the vendor's
   protocol.
3. Swap `new RiggedVRMRenderer(...)` for `new StreamingAvatarRenderer(...)`
   in `App.jsx`. The rest of the pipeline is unaffected because both
   implement the same `AvatarRenderer` interface.

## Operational note

This system generates a synthetic video of a person's likeness. If you
deploy this for anything other than local single-user testing, build in
(a) an on-screen "AI-generated avatar" disclosure baked into the output
stream, and (b) consent capture for whoever's face drives the rig — this
belongs in the product, not as an afterthought.
